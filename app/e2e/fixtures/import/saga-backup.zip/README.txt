SAGA Reader library export.

books/ holds your original files, unchanged.
annotations.md is a readable copy of your highlights and notes.
annotations.jsonld uses the W3C Web Annotation model so other tools can import it.
library.json holds everything SAGA needs to restore this library.
