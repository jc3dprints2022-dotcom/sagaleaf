# Highlights and notes

## Backup Tale
*Bea Backup*

> opens quietly

from the backup

— Ch 1 · 1%

